

from django.apps import AppConfig

class MatrimonyappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'matrimonyapp'

    def ready(self):
        import matrimonyapp.signals  # Ensure this matches your app's path
