from . import views
from django.urls import path
from django.shortcuts import redirect
from django.contrib.auth.views import LogoutView
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import LoginView, LogoutView
from .views import my_profile


urlpatterns = [
    path('', views.demo, name='home'),

    # Authentication
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout, name='logout'),
    path('register/', views.register, name='register'),
    path('register/', views.register_user, name='register_user'),
    path('registration-success/', views.registration_success, name='registration_success'),
    path('forgot-password/', views.forgot_password, name='forgot_password'),

    # Profile Management
    path('profile/', views.my_profile, name='my_profile'),
    path('update-contact-details/', views.update_contact_details, name='update_contact_details'),
    path('user/<str:username>/', views.user_details, name='user_detail'),
# urls.py
    path('update-religion-info/', views.update_religion_info, name='update_religion_info'),
    path('update-location/', views.update_location_details, name='update_location_details'),
    path('update-professional-info/', views.update_professional_info, name='update_professional_info'),
    path('update-astro-details/', views.update_astro_details, name='update_astro_details'),

    # Other Views
    path('success/', views.success, name='success'),
    path('profiles/', views.profile_list, name='profile_list'),
]