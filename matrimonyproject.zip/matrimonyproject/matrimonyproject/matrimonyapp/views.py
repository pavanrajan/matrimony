from django.core.checks import messages
from django.utils.dateparse import parse_time
from .models import UserProfile  # or your specific profile model
from .forms import UserProfileForm, RegistrationForm  # a form you'll create for editing
from django.shortcuts import render, redirect
from django.db import IntegrityError
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
# Create your views here.
def demo(request):
    return render(request, "index.html")

def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        try:
            user = UserProfile.objects.get(email=email, password=password)
            request.session['user_email'] = user.email  # store session
            return redirect('profile_list')
        except UserProfile.DoesNotExist:
            return render(request, 'login.html', {'error': 'Invalid credentials'})
    return render(request, 'login.html')

def register_user(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        dob = request.POST.get('dob')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        password = request.POST.get('password')

        # Check if email already exists
        if UserProfile.objects.filter(email=email).exists():
            return render(request, 'index.html', {'error': 'Email already registered'})

        # Save user
        UserProfile.objects.create(
            name=name,
            gender=gender,
            dob=dob,
            email=email,
            mobile=mobile,
            password=password  # NOTE: This should be hashed in production!
        )

        # Store email in session for login/session tracking
        request.session['user_email'] = email
        return redirect('dashboard')  # Update to your actual dashboard URL name

    return render(request, 'index.html')

def registration_success(request):
    return render(request, "success.html")

def forgot_password(request):
    return render(request, 'forgot_password.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data

            # Create and save the new user profile
            new_user = UserProfile.objects.create(
                name=cleaned_data['name'],
                gender=cleaned_data['gender'],
                religion=cleaned_data['religion'],
                dob=cleaned_data['dob'],
                caste=cleaned_data['caste'],
                sub_caste=cleaned_data.get('sub_caste', ''),
                language=cleaned_data.get('language', ''),
                drinking_habits=cleaned_data.get('drinking_habits', ''),
                smoking_habits=cleaned_data.get('smoking_habits', ''),
                profile_created_by=cleaned_data.get('profile_created_by', ''),
                highest_education=cleaned_data.get('highest_education', ''),
                occupation=cleaned_data.get('occupation', ''),
                annual_income=cleaned_data.get('annual_income', ''),
                country_living_in=cleaned_data.get('country_living_in', ''),
                state=cleaned_data.get('state', ''),
                city=cleaned_data.get('city', ''),
                mobile_number=cleaned_data['mobile_number'],
                email=cleaned_data['email'],
                password=cleaned_data['password'],
            )
            print("UserProfile created successfully:", new_user)

            return redirect('profile_list')
        else:
            print("Form errors:", form.errors)  # DEBUG: Print form validation errors
    else:
        form = RegistrationForm()

    return render(request, 'register.html', {'form': form})
def success(request):
    return render(request, 'success.html')

def profile_list(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        current_user = UserProfile.objects.get(email=email)
        opposite_gender = 'female' if current_user.gender == 'male' else 'male'
        profiles = UserProfile.objects.filter(gender=opposite_gender)
    except UserProfile.DoesNotExist:
        profiles = []

    return render(request, 'list.html', {'profiles': profiles})
def profile_view(request):
    if request.user.is_authenticated:
        user_profile = request.user.userprofile
    else:
        user_profile = None  # or redirect to login page
    return render(request, 'detail.html', {'user_profile': user_profile})



# @login_required(login_url='login')
def my_profile(request):
    # 1) ensure user is “logged in” via your session
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    # 2) fetch the profile from YOUR table
    try:
        profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        # if somehow they don’t have one, redirect to registration
        return redirect('register')

    # 3) handle edit form
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('my_profile')
    else:
        form = UserProfileForm(instance=profile)

    return render(request, 'detail.html', {
        'form':    form,
        'profile': profile,
    })



class UserEditForm:
    pass


def user_details(request):
    user = request.user  # Get the logged-in user

    if request.method == 'POST':
        # Create a form instance with the POST data and current user
        form = UserEditForm(request.POST, instance=user)

        if form.is_valid():
            form.save()  # Save the updated data to the database
            messages.success(request, "Your details have been updated successfully!")
            return redirect('user_details')  # Redirect to the same page to show updated data
    else:
        form = UserEditForm(instance=user)

def update_contact_details(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST':
        user_profile.contact_number = request.POST.get("contact_number")
        user_profile.parent_contact = request.POST.get("parent_contact")
        user_profile.chat_status = request.POST.get("chat_status")
        user_profile.send_mail = request.POST.get("send_mail")
        user_profile.save()
        return redirect('my_profile')  # or 'profile_view'
    return redirect('my_profile')

def profile_view(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    return render(request, 'detail.html', {'user_profile': user_profile})

def update_religion_info(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST':
        user_profile.religion = request.POST.get("religion")
        user_profile.caste = request.POST.get("caste")
        user_profile.sub_caste = request.POST.get("sub_caste")
        user_profile.star = request.POST.get("star")
        user_profile.raasi = request.POST.get("raasi")
        user_profile.dosh = request.POST.get("dosh")
        user_profile.save()
        return redirect('my_profile')

    return redirect('my_profile')

def update_location_details(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST':
        user_profile.country = request.POST.get("country")
        user_profile.state = request.POST.get("state")
        user_profile.citizenship = request.POST.get("citizenship")
        user_profile.city = request.POST.get("city")
        user_profile.save()
        return redirect('my_profile')

    return redirect('my_profile')


def profile_view(request):
    user_email = request.session.get('user_email')
    user_profile = UserProfile.objects.get(email=user_email)

    context = {
        'user_profile': user_profile,
    }
    return render(request, 'detail.html', context)

def update_professional_info(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST':
        user_profile.education = request.POST.get("education", "")
        user_profile.education_detail = request.POST.get("education_detail", "")
        user_profile.employed_in = request.POST.get("employed_in", "")
        user_profile.occupation = request.POST.get("occupation", "")
        user_profile.occupation_detail = request.POST.get("occupation_detail", "")
        user_profile.annual_income = request.POST.get("annual_income", "")  # prevent NULL

        user_profile.save()
        return redirect('my_profile')

    return redirect('my_profile')

def update_astro_details(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST':
        birth_date = request.POST.get("birth_date")
        birth_place = request.POST.get("birth_place")
        birth_time_str = request.POST.get("birth_time")
        manglik = request.POST.get("manglik")

        # Validate all required fields
        if not (birth_date and birth_place and birth_time_str and manglik):
            return redirect('my_profile')  # or show error message

        birth_time = parse_time(birth_time_str)
        if birth_time is None:
            return redirect('my_profile')  # or show error

        user_profile.birth_date = birth_date
        user_profile.birth_place = birth_place
        user_profile.birth_time = birth_time
        user_profile.manglik = manglik

        user_profile.save()
        return redirect('my_profile')

    return redirect('my_profile')
def update_profile_photo(request):
    email = request.session.get('user_email')
    if not email:
        return redirect('login')

    try:
        user_profile = UserProfile.objects.get(email=email)
    except UserProfile.DoesNotExist:
        return redirect('register')

    if request.method == 'POST' and request.FILES.get('profile_photo'):
        user_profile.profile_photo = request.FILES['profile_photo']
        user_profile.save()
        messages.success(request, "Profile photo updated successfully.")

    return redirect('my_profile')


def logout(request):
    request.session.flush()
    return redirect('login')

