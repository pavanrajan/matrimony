from django import forms

from matrimonyapp.models import UserProfile


GENDER_CHOICES = [
    ('male', 'Male'),
    ('female', 'Female'),
    ('other', 'Other'),
]

RELIGION_CHOICES = [
    (1, 'Hindu'),
    (2, 'Muslim'),
    (3, 'Sikh'),
    (4, 'Christian'),
    (5, 'Jain'),
]

CASTE_CHOICES = [
    ('general', 'General'),
    ('obc', 'OBC'),
    ('sc', 'SC'),
    ('st', 'ST'),
]



DRINKING_CHOICES = [
    ('occasionally', 'Occasionally'),
    ('socially', 'Socially'),
    ('yes', 'Yes'),
    ('no', 'No'),
    ('never', 'Never'),
]

SMOKING_CHOICES = [
    ('no', 'No'),
    ('occasionally', 'Occasionally'),
    ('yes', 'Yes'),
]

PROFILE_CREATED_BY_CHOICES = [
    ('self', 'Self'),
    ('parent', 'Parent'),
    ('sibling', 'Sibling'),
    ('friend', 'Friend'),
    ('relative', 'Relative'),
]

LANGUAGE_CHOICES = [
    ('hindi', 'Hindi'),
    ('telugu', 'Telugu'),
    ('tamil', 'Tamil'),
    ('punjabi', 'Punjabi'),
    ('bengali', 'Bengali'),
    ('english', 'English'),
]

COUNTRY_CHOICES = [
    ('india', 'India'),
    ('usa', 'USA'),
    ('uk', 'UK'),
    ('canada', 'Canada'),
    ('australia', 'Australia'),
    ('uae', 'UAE'),
]
class RegistrationForm(forms.Form):
    name = forms.CharField(max_length=255, required=True)
    gender = forms.ChoiceField(choices=GENDER_CHOICES, required=True)
    religion = forms.ChoiceField(choices=RELIGION_CHOICES, required=True)
    dob = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    caste = forms.ChoiceField(choices=CASTE_CHOICES, required=True)
    sub_caste = forms.CharField(max_length=255, required=False)
    language = forms.ChoiceField(choices=LANGUAGE_CHOICES, required=False)
    drinking_habits = forms.ChoiceField(choices=DRINKING_CHOICES, required=False)
    smoking_habits = forms.ChoiceField(choices=SMOKING_CHOICES, required=False)
    profile_created_by = forms.ChoiceField(choices=PROFILE_CREATED_BY_CHOICES, required=False)
    highest_education = forms.CharField(max_length=255, required=False)
    occupation = forms.CharField(max_length=255, required=False)
    annual_income = forms.CharField(max_length=255, required=False)
    country_living_in = forms.ChoiceField(choices=COUNTRY_CHOICES, required=False)
    state = forms.CharField(max_length=255, required=False)
    city = forms.CharField(max_length=255, required=False)
    mobile_number = forms.CharField(max_length=20, required=True)
    email = forms.EmailField(max_length=255, required=True)
    password = forms.CharField(widget=forms.PasswordInput, required=True)
    agree = forms.BooleanField(required=True)
#


GENDER_CHOICES = [
    ('male',   'Male'),
    ('female', 'Female'),
    ('other',  'Other'),
]

RELIGION_CHOICES = [
    ('1', 'Hindu'),
    ('2', 'Muslim'),
    ('3', 'Sikh'),
    ('4', 'Christian'),
    ('5', 'Jain'),
]

CASTE_CHOICES = [
    ('1', 'General'),
    ('2', 'OBC'),
    ('3', 'SC'),
    ('4', 'ST'),
]

LANGUAGE_CHOICES = [
    ('1', 'Hindi'),
    ('2', 'Telugu'),
    ('3', 'Tamil'),
    ('4', 'Punjabi'),
    ('5', 'Bengali'),
    ('6', 'English'),
]

DRINKING_CHOICES = [
    ('occasionally', 'Occasionally'),
    ('socially',     'Socially'),
    ('yes',          'Yes'),
    ('no',           'No'),
    ('never',        'Never'),
]

SMOKING_CHOICES = [
    ('no',         'No'),
    ('occasionally','Occasionally'),
    ('yes',        'Yes'),
]

PROFILE_CREATED_BY_CHOICES = [
    ('self',    'Self'),
    ('parent',  'Parent'),
    ('sibling', 'Sibling'),
    ('friend',  'Friend'),
    ('relative','Relative'),
]

COUNTRY_CHOICES = [
    ('india',     'India'),
    ('usa',       'USA'),
    ('uk',        'UK'),
    ('canada',    'Canada'),
    ('australia','Australia'),
    ('uae',       'UAE'),
]





class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile  # replace with your model name
        fields = '__all__'  # OR list specific fields like ['name', 'email', 'phone']

        # Optional: You can customize widgets for stylish fields
        widgets = {
            'name': forms.TextInput(attrs={
                'class': 'form-control form-control-lg',
                'placeholder': 'Full Name',
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control form-control-lg',
                'placeholder': 'Email Address',
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control form-control-lg',
                'placeholder': 'Phone Number',
            }),
        }
