from django.contrib.auth.models import User
from django.db import models
from datetime import datetime, time

class UserProfile(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]

    RELIGION_CHOICES = [
        ('1', 'Hindu'),
        ('2', 'Muslim'),
        ('3', 'Sikh'),
        ('4', 'Christian'),
        ('5', 'Jain'),
    ]

    CASTE_CHOICES = [
        ('general', 'General'),
        ('obc', 'OBC'),
        ('sc', 'SC'),
        ('st', 'ST'),
    ]

    LANGUAGE_CHOICES = [
        ('1', 'Hindi'),
        ('2', 'Telugu'),
        ('3', 'Tamil'),
        ('4', 'Punjabi'),
        ('5', 'Bengali'),
        ('6', 'English'),
    ]

    DRINKING_CHOICES = [
        ('occasionally', 'Occasionally'),
        ('socially', 'Socially'),
        ('yes', 'Yes'),
        ('no', 'No'),
        ('never', 'Never'),
    ]

    SMOKING_CHOICES = [
        ('no', 'No'),
        ('occasionally', 'Occasionally'),
        ('yes', 'Yes'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)

    # Basic Info
    name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True, null=True)
    dob = models.DateField(blank=True, null=True)
    religion = models.CharField(max_length=50, choices=RELIGION_CHOICES, blank=True, null=True)
    caste = models.CharField(max_length=50, choices=CASTE_CHOICES, blank=True, null=True)
    sub_caste = models.CharField(max_length=100, blank=True, null=True)
    language = models.CharField(max_length=50, choices=LANGUAGE_CHOICES, blank=True, null=True)
    profile_created_by = models.CharField(max_length=50, blank=True, null=True)

    # Lifestyle
    drinking_habits = models.CharField(max_length=50, choices=DRINKING_CHOICES, blank=True, null=True)
    smoking_habits = models.CharField(max_length=50, choices=SMOKING_CHOICES, blank=True, null=True)

    # Education & Occupation
    # Add this back if it was removed


    highest_education = models.CharField(max_length=100, blank=True, null=True)
    occupation = models.CharField(max_length=100, blank=True, null=True)
    annual_income = models.CharField(max_length=50, default="Not specified", blank=True, null=True)
    # Add this back if it was removed


    # Location
    country_living_in = models.CharField(max_length=100, blank=True, null=True)
    state = models.CharField(max_length=100, blank=True, null=True)
    city = models.CharField(max_length=100, blank=True, null=True)
    citizenship = models.CharField(max_length=50, default='Indian', blank=True, null=True)

    # Astro Details
    birth_time = models.TimeField(default=time(0, 0), blank=True, null=True)
    birth_place = models.CharField(max_length=100, default='Not specified')

    star = models.CharField(max_length=100, default='Not specified')

    raasi = models.CharField(max_length=100, default='Not specified')
    dosh = models.CharField(max_length=100, default='Not specified', blank=True, null=True)

    # Contact Info
    email = models.EmailField()
    mobile_number = models.CharField(max_length=20)
    contact_number = models.CharField(max_length=20,default='Not specified')
    parent_contact = models.CharField(max_length=20, default='Not specified')
    password = models.CharField(max_length=255)

    # Profile Settings
    chat_status = models.CharField(max_length=10, choices=[('Yes', 'Yes'), ('No', 'No')], default='Yes')
    send_mail = models.CharField(max_length=10, choices=[('Yes', 'Yes'), ('No', 'No')], default='Yes')
    # Photo


    def __str__(self):
        return self.name